﻿// Mock API to fix loading loops and backend errors
window.mockAPI = {
    currentUser: { id: 1, name: "Demo User", email: "demo@example.com", subscription: "free" },
    paymentConfig: { public_key: "pk_test_demo", currency: "ZAR" }
};

const originalFetch = window.fetch;
window.fetch = function(url, options) {
    if (url.includes('/api/payment/config')) {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(window.mockAPI.paymentConfig) });
    }
    if (url.includes('/api/user') || url.includes('/api/auth')) {
        return Promise.resolve({ ok: true, json: () => Promise.resolve(window.mockAPI.currentUser) });
    }
    return originalFetch.apply(this, arguments);
};
window.currentUser = window.mockAPI.currentUser;
